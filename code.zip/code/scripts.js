$(function() {
    const viewwidth = window.innerWidth;
    let dooropen = 0;
    var elem = document.getElementById("castle");
    console.log(viewwidth);
    	$(window).scroll(function() {
		var value = $(this).scrollTop(); //スクロールの値を取得
		$('#scrollValue').text(value);
        $('#blueback').css('opacity', 4 -( value/160));
        $('#orangeback').css('opacity',5 - (value/300));
        $('#castle').css('right',40 + (value/4)-((value/4)%5));
        $('#castle').css('opacity',15-(value/100));
        $('#ground').css('opacity',15-(value/100));
        $('#crowd1').css('right',260 + (value/20));
        $('#crowd2').css('right',70 + (value/10));
        $('#crowd3').css('right',120 + (value/12));
        if(viewwidth-(40 + (value/4)-((value/4)%5))<140){
            $('#maid').fadeOut(100);
        }
        if (viewwidth-(40 + (value/4)-((value/4)%5))<120){
            dooropen+=1;
        }
        if (viewwidth-(40 + (value/4)-((value/4)%5))>120 && viewwidth-(40 + (value/4)-((value/4)%5))<180 && dooropen ==0){
         
        elem.src="img/castle-open.png";    }else{
            elem.src="img/castle.png";
        }
        if(value > 1400){
            gsap.timeline().to('.stars',30,{scale:1.5}).to('.stars',30,{x:-50},"-=30");      
        }
        if(value>1050 && value<1450){
            $('.news').fadeIn();
            gsap.to('.news',0.5,{right:8});


        }else{
            $('.news').fadeOut();
            gsap.to('.news',0.5,{right:-250});
        }
    });
       
});